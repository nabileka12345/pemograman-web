<?php
namespace MyApp\Classes;

class Bicycle extends Vehicle {
    public function startEngine() {
        echo "Sepeda tidak memiliki mesin untuk dinyalakan.\n";
    }
}
