<?php
namespace MyApp\Classes;

use MyApp\Traits\Logger;

class Car extends Vehicle {
    use Logger; // Menggunakan trait Logger

    private $fuelType;

    public function __construct($brand, $model, $fuelType) {
        parent::__construct($brand, $model);
        $this->fuelType = $fuelType;
    }

    // Implementasi dari metode abstrak
    public function startEngine() {
        echo "Mesin mobil {$this->brand} {$this->model} menyala.\n";
    }

    public function getFuelType() {
        return $this->fuelType;
    }
}
