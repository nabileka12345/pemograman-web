<?php
namespace MyApp\Classes;

abstract class Vehicle {
    protected $brand;
    protected $model;

    public function __construct($brand, $model) {
        $this->brand = $brand;
        $this->model = $model;
    }

    // Metode abstrak yang harus diimplementasikan oleh kelas turunannya
    abstract public function startEngine();

    // Magic method untuk output informasi
    public function __toString() {
        return "{$this->brand} {$this->model}";
    }
}
