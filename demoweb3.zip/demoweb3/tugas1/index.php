<?php
require_once __DIR__ . '/traits/Logger.php';
require_once __DIR__ . '/classes/Vehicle.php';
require_once __DIR__ . '/classes/Car.php';
require_once __DIR__ . '/classes/Bicycle.php';

use MyApp\Classes\Car;
use MyApp\Classes\Bicycle;

// Contoh penggunaan
$car = new Car("Toyota", "Corolla", "Bensin");
echo $car->startEngine();
echo $car->log("Mobil siap digunakan.");
echo "Tipe bahan bakar: " . $car->getFuelType() . "\n";
echo $car . "\n"; // Menggunakan magic method __toString

$bicycle = new Bicycle("Polygon", "Heist X5");
echo $bicycle->startEngine();
