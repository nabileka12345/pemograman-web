<?php
// functions.php

function cetakAngka($n) {
    // Perulangan dari 1 hingga n
    for ($i = 1; $i <= $n; $i++) {
        // Cek apakah angka habis dibagi 4 dan 6
        if ($i % 4 == 0 && $i % 6 == 0) {
            echo "Pemrograman Website 2024\n";
        }
        // Cek apakah angka habis dibagi 5
        else if ($i % 5 == 0) {
            echo "2024\n";
        }
        // Cek apakah angka habis dibagi 4 tetapi tidak habis dibagi 6
        else if ($i % 4 == 0 && $i % 6 != 0) {
            echo "Pemrograman\n";
        }
        // Cek apakah angka habis dibagi 6 tetapi tidak habis dibagi 4
        else if ($i % 6 == 0 && $i % 4 != 0) {
            echo "Website\n";
        }
        // Jika tidak memenuhi kondisi apapun, cetak angkanya
        else {
            echo $i . "\n";
        }
    }
}
