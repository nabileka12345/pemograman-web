<?php
// index.php

// Memasukkan file functions.php
require_once 'functions.php';

// Memanggil fungsi cetakAngka dengan nilai n
$n = 20; // Anda dapat mengubah nilai ini sesuai kebutuhan
cetakAngka($n);
